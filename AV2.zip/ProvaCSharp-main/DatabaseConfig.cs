namespace AtividadeAvaliativa.Database;

class DatabaseConfig
{
    public string ConnectionString { get => "Data Source=database.db"; }
}